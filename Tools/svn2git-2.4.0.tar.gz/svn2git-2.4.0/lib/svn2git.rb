require File.dirname(__FILE__) + '/svn2git/migration'

