package io.zhile.crack.atlassian.license;

/**
 * @author pengzhile
 * @version 1.0
 * @link https://zhile.io
 */
public enum LicenseEdition {
    BASIC,
    STANDARD,
    PROFESSIONAL,
    ENTERPRISE,
    UNLIMITED,
}
